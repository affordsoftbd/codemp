
<p>Your password in Amar Neta app has been changed.</p>
<p>Your new password is: {{ $password}}</p>