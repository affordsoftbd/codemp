<!-- 
<button type="button" class="btn btn-danger" id="appendnewcontainer">Click me To create new slider</button>
<div id="fotoappendarea"> 
<div class="card my-4">
    <div class="card-body">
        <div class="row">
            <div class="col-xl-1 col-lg-2 col-md-2">
                <img src="https://mdbootstrap.com/img/Photos/Avatars/img%20(18)-mini.jpg" class="rounded-circle z-depth-1-half">
            </div>
            <div class="col-xl-11 col-lg-10 col-md-10">
                <h6 class="font-weight-bold">Gracie Monahan</h6>
                <small class="grey-text">Monday 20 August 2018, 09:50 AM</small>
            </div>
        </div>
        <hr>
        Doloremque doloremque fuga nostrum harum. Omnis totam id alias dolorum qui. Recusandae assumenda adipisci ut enim rerum aut repudiandae. Nihil quia temporibus quam sapiente ut. Accusamus tenetur labore fuga incidunt. Recusandae porro ipsam cumque ut consequatur. Non et sed et quisquam ipsa et praesentium. Odit aut culpa earum consequatur sit quis. Consequatur est error mollitia ex aliquid. Quia tempore quae qui adipisci quidem laboriosam voluptates.
    </div>
  <a class="btn-floating btn-action ml-auto mr-4 mb-4 red" data-toggle="modal" data-target="#modalSubscriptionForm"><i class="fa fa-edit pl-1"></i></a>
    <div class="view overlay my-4" align="center">
        <div class="lightgallery">
            <p><span id="counter1">1</span> of 04</p>
            <ul class="lightSlider">
                <li data-thumb="http://sachinchoolur.github.io/lightslider/img/thumb/cS-1.jpg" data-src="http://sachinchoolur.github.io/lightslider/img/cS-1.jpg" data-sub-html="Focused client-server ability 10">
                    <img src="http://sachinchoolur.github.io/lightslider/img/cS-1.jpg" />
                </li>
                <li data-thumb="http://sachinchoolur.github.io/lightslider/img/thumb/cS-1.jpg" data-src="http://sachinchoolur.github.io/lightslider/img/cS-2.jpg" data-sub-html="Focused client-server ability 10">
                    <img src="http://sachinchoolur.github.io/lightslider/img/cS-2.jpg" />
                </li>
                <li data-thumb="http://sachinchoolur.github.io/lightslider/img/thumb/cS-3.jpg" data-src="http://sachinchoolur.github.io/lightslider/img/cS-3.jpg" data-sub-html="Focused client-server ability 10">
                    <img src="http://sachinchoolur.github.io/lightslider/img/cS-3.jpg" />
                </li>
                <li data-thumb="http://sachinchoolur.github.io/lightslider/img/thumb/cS-4.jpg" data-src="http://sachinchoolur.github.io/lightslider/img/cS-4.jpg" data-sub-html="Focused client-server ability 10">
                    <img src="http://sachinchoolur.github.io/lightslider/img/cS-4.jpg" />
                </li>
            </ul>
        </div> 
    </div>
  <div class="rounded-bottom green text-center pt-3">
    <ul class="list-unstyled list-inline font-small">
        <li class="list-inline-item pr-2"><a href="#" class="white-text"><i class="fa fa-thumbs-o-up pr-1"></i>12</a></li>
        <li class="list-inline-item"><a href="#" class="white-text"><i class="fa fa-facebook pr-1"></i>5</a></li>
        <li class="list-inline-item"><a href="#" class="white-text"><i class="fa fa-twitter pr-1"></i>4</a></li>
        <li class="list-inline-item"><a href="{{ route('image') }}" class="white-text"><i class="fa fa-comments-o pr-1"></i>12</a></li>
    </ul>
  </div>
</div> 
 
</div> -->


<!--div class="success_messages hidden">
    <h1>স্বাগতম!</h1>
    <p>আপনি সফলভাবে লগ ইন করেছেন!</p>
</div-->

<script>
            /*var imagesarray = [
                "https://www.elastic.co/assets/bltada7771f270d08f6/enhanced-buzz-1492-1379411828-15.jpg",
                "https://images.pexels.com/photos/236047/pexels-photo-236047.jpeg?auto=compress&cs=tinysrgb&h=350"
            ];
            var hiddenimages = "",
                    albumcover;
            function refreshSlider(){ 
                $('.lightSlider').each(function (index) {
                    $(this).lightSlider({
                        gallery: true,
                        item: 1,
                        loop: true,
                        slideMargin: 0,
                        thumbItem: 9,
                        onBeforeSlide: function (el) {
                            $('.slidercount:eq('+index+')').text(el.getCurrentSlideCount());
                        },
                        onSliderLoad: function(el) {
                            el.lightGallery({
                                selector: '.lightgallery .lslide'
                            });
                        }
                    });
                });               
            }  
            var slider = refreshSlider(); 
            $("#appendnewcontainer").click(function() {
                if($('.lightSlider').length){
                    // slider.destroy();  
                    // $('.lightSlider').lightSlider().destroy();
                }
                $("#fotoappendarea").append("<div class='lightgallery my-5'><p><span class='slidercount'>1</span> of "+imagesarray.length+"</p><ul class= 'lightSlider'><li data-thumb=" + imagesarray[0] + " data-src=" + imagesarray[0] + "><img src='" + imagesarray[0] + "' class='_34'/></li><li data-thumb=" + imagesarray[1] + " data-src=" + imagesarray[1] + "><img src='" + imagesarray[1] + "' class='_34'/></li></ul></div>");
                slider = refreshSlider();
            });*/
</script>