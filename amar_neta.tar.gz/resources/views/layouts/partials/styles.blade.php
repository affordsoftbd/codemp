
    <!-- Animation Css -->
    {{ Html::style('plugins/animate-css/animate.css') }}

    <!-- Sweetalert Css -->
    {{ Html::style('plugins/sweetalert/sweetalert.css') }}

    <!-- Bootstrap Spinner Css -->
    {{ Html::style('plugins/jquery-spinner/css/bootstrap-spinner.css') }}

    <!-- Bootstrap Tagsinput Css -->
    {{ Html::style('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css') }}

    <!-- Bootstrap Material Datetime Picker Css -->
    {{ Html::style('plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css') }}

    <!-- Image Slider Css -->
    {{ Html::style('plugins/light-gallery/css/lightgallery.css') }}
    
    <!-- Image Slider Css -->
    {{ Html::style('plugins/light-slider/css/lightslider.css') }}

    <!-- Jqurey Datatable Css -->
    {{ Html::style('plugins/material-addons/css/datatables.min.css') }}

    <!-- Material Design Bootstrap -->
    {{ Html::style('css/material.min.css') }}

     <!-- Video Css -->
    {{ Html::style('https://vjs.zencdn.net/7.2.3/video-js.css') }}

    <!-- Custom styles for this template -->
    {{ Html::style('css/style.css') }}