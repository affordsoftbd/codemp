<?php

namespace App;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;

/**
 * Class Common, this class is to use project common functions
 *
 * @package App
 */
class Common
{
    const SITE_TITLE = 'Amar Neta';
    const ADMIN_EMAIL = 'muhin.diu092@gmail.com';

}//End