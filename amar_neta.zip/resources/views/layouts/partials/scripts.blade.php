    <!-- Sweet Alert -->
 	{{Html::script('plugins/sweetalert/sweetalert.min.js')}}

    <!-- Bootstrap Notify -->
 	{{Html::script('plugins/bootstrap-notify/bootstrap-notify.min.js')}}

    <!-- Light Gallery Plugin Js -->
 	{{Html::script('plugins/light-gallery/js/lightgallery-all.js')}}

    <!-- Light Slider Plugin Js -->
 	{{Html::script('plugins/light-slider/js/lightslider.js')}}

    <!-- Slimscroll Plugin Js -->
 	{{Html::script('plugins/jquery-slimscroll/jquery.slimscroll.js')}}

    <!-- Autosize Plugin Js -->
 	{{Html::script('plugins/autosize/autosize.js')}}

    <!-- Jquery Spinner Plugin Js -->
 	{{Html::script('plugins/jquery-spinner/js/jquery.spinner.js')}}

    <!-- Bootstrap Tags Input Plugin Js -->
 	{{Html::script('plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')}}

    <!-- Moment Plugin Js -->
 	{{Html::script('plugins/momentjs/moment.js')}}

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
 	{{Html::script('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js')}}

    <!-- DropJone Js -->
    {{Html::script('js/dropzone.js')}}

    <!-- TinyMCE -->
 	{{Html::script('plugins/tinymce/tinymce.min.js')}}

    <!-- Jqurey Datatable Js -->
    {{Html::script('plugins/material-addons/js/datatables.min.js') }}

    <!-- MDB core JavaScript -->
 	{{Html::script('js/material.min.js')}}

    <!-- Video JavaScript -->
    {{Html::script('js/video.js')}}

    <!-- Custom JavaScript -->
 	{{Html::script('js/script.js')}}
 	{{Html::script('js/image-slider-gallery.js')}}
 	{{Html::script('js/basic-form-elements.js')}}