<!-- Scroll to top button -->
<div id="scrollToTopButton" class="fixed-action-btn smooth-scroll scrolltotop">
    <a class="btn-floating btn-large red">
        <i class="fa fa-arrow-up"></i>
    </a>
</div>
<!-- #END# Scroll to top button --> 