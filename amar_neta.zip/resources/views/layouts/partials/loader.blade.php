<!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
            <p>একটু অপেক্ষা করুন...</p>
        </div>
    </div>
<!-- #ENDS# Page Loader -->